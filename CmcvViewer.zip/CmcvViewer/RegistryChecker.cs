using System;
using System.Collections.Generic;
using Microsoft.Win32;

namespace CmcvViewer
{

    public static class RegistryChecker
    {
        private const string ControlRoot = @"SYSTEM\CurrentControlSet\Control";

        public static void Annotate(IEnumerable<CmcvEntry> entries)
        {
            using var control = RegistryModel.OpenBase(RegistryHive.LocalMachine)
                                           .OpenSubKey(ControlRoot, writable: false);
            if (control == null) return;

            foreach (var e in entries)
            {
                string rel = Normalize(e.KeyPath);
                RegistryKey? key = null;
                try
                {
                    key = rel.Length == 0 ? control : control.OpenSubKey(rel, writable: false);
                    if (key == null)
                    {
                        e.KeyExists = false;
                        e.ValueExists = false;
                        continue;
                    }

                    e.KeyExists = true;

                    if (string.IsNullOrEmpty(e.ValueName))
                    {

                        e.ValueExists = false;
                        continue;
                    }

                    bool found = false;
                    foreach (var vn in key.GetValueNames())
                    {
                        if (string.Equals(vn, e.ValueName, StringComparison.OrdinalIgnoreCase))
                        { found = true; break; }
                    }
                    e.ValueExists = found;
                    if (found)
                    {
                        object? data = key.GetValue(e.ValueName, null,
                            RegistryValueOptions.DoNotExpandEnvironmentNames);
                        e.Data = Describe(data);
                    }
                }
                catch
                {
                    e.KeyExists = false;
                    e.ValueExists = false;
                }
                finally
                {
                    if (key != null && key != control) key.Dispose();
                }
            }
        }

        private static string Normalize(string keyPath)
        {
            if (string.IsNullOrEmpty(keyPath)) return "";
            string p = keyPath.Replace('/', '\\').Trim('\\');

            int idx = p.IndexOf(@"Control\", StringComparison.OrdinalIgnoreCase);
            if (idx >= 0) p = p.Substring(idx + "Control\\".Length);
            else if (p.Equals("Control", StringComparison.OrdinalIgnoreCase)) p = "";

            return p.Trim('\\');
        }

        private static string Describe(object? data)
        {
            if (data == null) return "";
            if (data is byte[] bytes) return BitConverter.ToString(bytes);
            if (data is string[] multi) return string.Join(" | ", multi);
            return data.ToString() ?? "";
        }
    }
}
