using Microsoft.Win32;

namespace CmcvViewer
{
    public sealed class Bookmark
    {
        public string Label = "";
        public RegistryHive Hive;
        public string Path = "";
    }

    public static class Bookmarks
    {
        public static readonly Bookmark[] All =
        {
            new() { Label = "Control",                     Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Control" },
            new() { Label = "GraphicsDrivers",             Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers" },
            new() { Label = "GraphicsDrivers\\Scheduler (ControlSet001)", Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\ControlSet001\Control\GraphicsDrivers\Scheduler" },
            new() { Label = "PriorityControl",             Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Control\PriorityControl" },
            new() { Label = "Multimedia\\SystemProfile",   Hive = RegistryHive.LocalMachine, Path = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" },
            new() { Label = "Session Manager",             Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Control\Session Manager" },
            new() { Label = "Memory Management",           Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" },
            new() { Label = "Lsa",                         Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Control\Lsa" },
            new() { Label = "Power",                       Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Control\Power" },
            new() { Label = "Services",                    Hive = RegistryHive.LocalMachine, Path = @"SYSTEM\CurrentControlSet\Services" },
            new() { Label = "GameConfigStore",             Hive = RegistryHive.CurrentUser,  Path = @"System\GameConfigStore" },
            new() { Label = "GameBar (HKCU)",              Hive = RegistryHive.CurrentUser,  Path = @"Software\Microsoft\GameBar" },
        };
    }
}
