using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Microsoft.Win32;

namespace CmcvViewer
{

    public sealed class TreeNode
    {
        public string Name = "";
        public string? FullPath;
        public RegistryHive Hive = RegistryHive.LocalMachine;
        public bool HasValues;
        public bool Exists = true;
        public ObservableCollection<TreeNode> Children { get; } = new();

        public bool ChildrenLoaded;

        public string Display => Exists ? Name : Name + "  (absent)";

        public Microsoft.UI.Xaml.Media.SolidColorBrush NameBrush =>
            new(Exists ? Windows.UI.Color.FromArgb(255, 0xE0, 0xE0, 0xE0)
                       : Windows.UI.Color.FromArgb(255, 0x70, 0x70, 0x70));

        public Microsoft.UI.Xaml.Media.SolidColorBrush FolderBrush =>
            new(HasValues ? Windows.UI.Color.FromArgb(255, 0x4C, 0xC2, 0xFF)
                          : Windows.UI.Color.FromArgb(255, 0x8A, 0x8A, 0x8A));
    }

    public sealed class ValueRow
    {
        public string Name = "";
        public string Type = "";
        public string Data = "";

        public bool CanCreate;
        public RegistryHive TargetHive = RegistryHive.LocalMachine;
        public string TargetKeyPath = "";
        public string TargetValueName = "";

        public Microsoft.UI.Xaml.Visibility CreateVisibility =>
            CanCreate ? Microsoft.UI.Xaml.Visibility.Visible : Microsoft.UI.Xaml.Visibility.Collapsed;

        public Microsoft.UI.Xaml.Media.SolidColorBrush TypeBrush =>
            new(Type == "value" ? Windows.UI.Color.FromArgb(255, 0x6A, 0xD4, 0x6A)
              : Type == "key"   ? Windows.UI.Color.FromArgb(255, 0xDC, 0xBE, 0x5A)
              : Type == "absent"? Windows.UI.Color.FromArgb(255, 0x88, 0x88, 0x88)
              : Windows.UI.Color.FromArgb(255, 0xC5, 0x86, 0xC0));
    }

    public static class RegistryModel
    {

        public static RegistryKey OpenBase(RegistryHive hive) =>
            RegistryKey.OpenBaseKey(hive, RegistryView.Registry64);

        public static TreeNode BuildNode(RegistryHive hive, string path, string displayName)
        {
            var node = new TreeNode { Name = displayName, FullPath = path, Hive = hive };
            try
            {
                using var baseKey = OpenBase(hive);
                using var key = string.IsNullOrEmpty(path) ? baseKey : baseKey.OpenSubKey(path, false);
                if (key == null) { node.Exists = false; return node; }
                node.HasValues = key.ValueCount > 0;
                LoadChildren(node);
            }
            catch { node.Exists = false; }
            return node;
        }

        public static void LoadChildren(TreeNode node)
        {
            if (node.ChildrenLoaded || node.FullPath == null) return;
            node.ChildrenLoaded = true;
            node.Children.Clear();
            try
            {
                using var baseKey = OpenBase(node.Hive);
                using var key = node.FullPath.Length == 0 ? baseKey : baseKey.OpenSubKey(node.FullPath, false);
                if (key == null) { node.Exists = false; return; }

                foreach (var sub in key.GetSubKeyNames())
                {
                    var childPath = node.FullPath.Length == 0 ? sub : node.FullPath + "\\" + sub;
                    var child = new TreeNode { Name = sub, FullPath = childPath, Hive = node.Hive };
                    try
                    {
                        using var ck = key.OpenSubKey(sub, false);
                        child.HasValues = ck != null && ck.ValueCount > 0;

                        if (ck != null && ck.SubKeyCount > 0)
                            child.Children.Add(new TreeNode { Name = "…", Exists = false, FullPath = null });
                    }
                    catch { child.Exists = false; }
                    node.Children.Add(child);
                }
            }
            catch {  }
        }

        public static List<ValueRow> ListValues(RegistryHive hive, string path)
        {
            var rows = new List<ValueRow>();
            try
            {
                using var baseKey = OpenBase(hive);
                using var key = string.IsNullOrEmpty(path) ? baseKey : baseKey.OpenSubKey(path, false);
                if (key == null) return rows;

                foreach (var name in key.GetValueNames())
                {
                    string typeText;
                    string dataText;
                    try
                    {
                        RegistryValueKind kind;
                        try { kind = key.GetValueKind(name); }
                        catch { kind = RegistryValueKind.Unknown; }

                        object? data = key.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                        typeText = kind.ToString();
                        dataText = Describe(data, kind);
                    }
                    catch (Exception ex)
                    {
                        typeText = "(?)";
                        dataText = "<unreadable: " + ex.GetType().Name + ">";
                    }

                    rows.Add(new ValueRow
                    {
                        Name = string.IsNullOrEmpty(name) ? "(Default)" : name,
                        Type = typeText,
                        Data = dataText,
                    });
                }
            }
            catch (Exception ex)
            {
                rows.Add(new ValueRow { Name = "(error)", Type = "", Data = ex.Message });
            }
            return rows;
        }

        private static string Describe(object? data, RegistryValueKind kind)
        {
            if (data == null) return "";

            switch (data)
            {
                case byte[] b:
                    return b.Length <= 512 ? BitConverter.ToString(b)
                                           : BitConverter.ToString(b, 0, 512) + " …";
                case string[] ms:
                    return string.Join(" | ", ms);
                case int i:
                    return $"0x{(uint)i:X8} ({i})";
                case long l:
                    return $"0x{(ulong)l:X16} ({l})";
                default:
                    return data.ToString() ?? "";
            }
        }

        public static bool TryParsePath(string input, out RegistryHive hive, out string path)
        {
            hive = RegistryHive.LocalMachine;
            path = "";
            if (string.IsNullOrWhiteSpace(input)) return false;

            string s = input.Trim().Replace('/', '\\');
            int slash = s.IndexOf('\\');
            string root = slash < 0 ? s : s.Substring(0, slash);
            path = slash < 0 ? "" : s.Substring(slash + 1);

            switch (root.ToUpperInvariant())
            {
                case "HKLM":
                case "HKEY_LOCAL_MACHINE": hive = RegistryHive.LocalMachine; return true;
                case "HKCU":
                case "HKEY_CURRENT_USER": hive = RegistryHive.CurrentUser; return true;
                case "HKCR":
                case "HKEY_CLASSES_ROOT": hive = RegistryHive.ClassesRoot; return true;
                case "HKU":
                case "HKEY_USERS": hive = RegistryHive.Users; return true;
                default: return false;
            }
        }
    }
}
