using System;
using System.Runtime.InteropServices;
using System.Text;

namespace CmcvViewer
{

    internal sealed class PeImage
    {
        private readonly ulong _base;
        private readonly (ulong Start, ulong End)[] _sections;
        public bool IsWin10Rs4OrLater { get; private set; }

        private PeImage(ulong imageBase, (ulong, ulong)[] sections, bool rs4)
        {
            _base = imageBase;
            _sections = sections;
            IsWin10Rs4OrLater = rs4;
        }

        public static PeImage Parse(ulong imageBase)
        {
            int e_lfanew = Marshal.ReadInt32((IntPtr)(long)(imageBase + 0x3C));
            ulong nt = imageBase + (uint)e_lfanew;
            short numberOfSections = Marshal.ReadInt16((IntPtr)(long)(nt + 4 + 2));
            short sizeOfOptional = Marshal.ReadInt16((IntPtr)(long)(nt + 4 + 16));
            ulong optional = nt + 24;
            ulong firstSection = optional + (uint)sizeOfOptional;

            var secs = new (ulong, ulong)[numberOfSections];
            for (int i = 0; i < numberOfSections; i++)
            {
                ulong sh = firstSection + (ulong)(i * 40);
                uint virtualSize = (uint)Marshal.ReadInt32((IntPtr)(long)(sh + 8));
                uint virtualAddr = (uint)Marshal.ReadInt32((IntPtr)(long)(sh + 12));
                ulong s = imageBase + virtualAddr;
                secs[i] = (s, s + Math.Max(virtualSize, 1));
            }

            var os = Environment.OSVersion.Version;
            bool rs4 = os.Major > 10 || (os.Major == 10 && os.Build >= 17134);

            return new PeImage(imageBase, secs, rs4);
        }

        public bool Contains(ulong addr)
        {
            foreach (var (s, en) in _sections)
                if (addr >= s && addr < en) return true;
            return false;
        }

        public bool IsReadableStringPointer(ulong addr)
        {
            if (!Contains(addr)) return false;

            try
            {
                int printable = 0;
                for (int i = 0; i < 4; i++)
                {
                    char c = (char)Marshal.ReadInt16((IntPtr)(long)(addr + (ulong)(i * 2)));
                    if (c == 0) break;

                    bool ok = (c >= 0x20 && c <= 0x7E);
                    if (!ok) return false;
                    printable++;
                }
                return printable > 0;
            }
            catch { return false; }
        }

        public ulong ReadPtr(ulong addr) => (ulong)Marshal.ReadInt64((IntPtr)(long)addr);
        public uint ReadU32(ulong addr) => (uint)Marshal.ReadInt32((IntPtr)(long)addr);

        public string ReadWideString(ulong addr)
        {
            var sb = new StringBuilder(128);
            for (int i = 0; i < 512; i++)
            {
                short w = Marshal.ReadInt16((IntPtr)(long)(addr + (ulong)(i * 2)));
                if (w == 0) break;
                sb.Append((char)w);
            }
            return sb.ToString();
        }

        public ulong FindBytes(byte[] needle)
        {
            foreach (var (s, en) in _sections)
            {
                long len = (long)(en - s);
                for (long off = 0; off <= len - needle.Length; off++)
                {
                    bool match = true;
                    for (int k = 0; k < needle.Length; k++)
                    {
                        if (Marshal.ReadByte((IntPtr)(long)(s + (ulong)(off + k))) != needle[k])
                        { match = false; break; }
                    }
                    if (match) return s + (ulong)off;
                }
            }
            return 0;
        }

        public ulong FindPointerTo(ulong target)
        {
            foreach (var (s, en) in _sections)
            {
                for (ulong p = s; p + 8 <= en; p += 8)
                {
                    if ((ulong)Marshal.ReadInt64((IntPtr)(long)p) == target)
                        return p;
                }
            }
            return 0;
        }

        public System.Collections.Generic.List<ulong> FindAllPointersTo(ulong target)
        {
            var hits = new System.Collections.Generic.List<ulong>();
            foreach (var (s, en) in _sections)
            {
                for (ulong p = s; p + 8 <= en; p += 8)
                {
                    if ((ulong)Marshal.ReadInt64((IntPtr)(long)p) == target)
                        hits.Add(p);
                }
            }
            return hits;
        }
    }
}
