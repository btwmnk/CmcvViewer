using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace CmcvViewer
{

    public static class KUserSharedDataReader
    {
        private const long KUSER = 0x7FFE0000;

        public static List<ValueRow> Read()
        {
            var rows = new List<ValueRow>();
            try
            {
                rows.Add(Row("TickCountLowDeprecated", "ULONG", "0x" + ReadU32(0x0).ToString("X8")));
                rows.Add(Row("NtSystemRoot", "WCHAR[]", ReadWide(0x30, 260)));
                rows.Add(Row("NtProductType", "ULONG", ReadU32(0x264).ToString()));
                rows.Add(Row("NtMajorVersion", "ULONG", ReadU32(0x26C).ToString()));
                rows.Add(Row("NtMinorVersion", "ULONG", ReadU32(0x270).ToString()));
                rows.Add(Row("NtBuildNumber", "ULONG", ReadU32(0x260).ToString()));
                rows.Add(Row("BootId", "ULONG", "0x" + ReadU32(0x2C4).ToString("X")));
                rows.Add(Row("SafeBootMode", "UCHAR", ReadU8(0x2EC).ToString()));
                rows.Add(Row("KdDebuggerEnabled", "UCHAR", "0x" + ReadU8(0x2D4).ToString("X2")));
                rows.Add(Row("ActiveProcessorCount", "ULONG", ReadU32(0x3C0).ToString()));
                rows.Add(Row("ActiveGroupCount", "USHORT", ReadU8(0x3C4).ToString()));
                rows.Add(Row("Cookie", "ULONG", "0x" + ReadU32(0x330).ToString("X8")));
                rows.Add(Row("ImageNumberLow", "USHORT", "0x" + ReadU16(0x33C).ToString("X4")));
                rows.Add(Row("ImageNumberHigh", "USHORT", "0x" + ReadU16(0x33E).ToString("X4")));
            }
            catch (Exception ex)
            {
                rows.Add(Row("(error)", "", ex.Message));
            }
            return rows;
        }

        private static ValueRow Row(string n, string t, string d) => new() { Name = n, Type = t, Data = d };

        private static byte ReadU8(int off) => Marshal.ReadByte((IntPtr)(KUSER + off));
        private static ushort ReadU16(int off) => (ushort)Marshal.ReadInt16((IntPtr)(KUSER + off));
        private static uint ReadU32(int off) => (uint)Marshal.ReadInt32((IntPtr)(KUSER + off));

        private static string ReadWide(int off, int maxChars)
        {
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < maxChars; i++)
            {
                short c = Marshal.ReadInt16((IntPtr)(KUSER + off + i * 2));
                if (c == 0) break;
                sb.Append((char)c);
            }
            return sb.ToString();
        }
    }
}
