using System;
using System.Globalization;
using System.Linq;
using Microsoft.Win32;

namespace CmcvViewer
{
    public enum NewValueType { String, ExpandString, Dword, Qword, Binary, MultiString }

    public readonly struct WriteResult
    {
        public readonly bool Ok;
        public readonly string Message;
        public WriteResult(bool ok, string msg) { Ok = ok; Message = msg; }
    }

    public static class RegistryWriter
    {
        public static WriteResult CreateValue(
            RegistryHive hive, string keyPath, string valueName,
            string rawData, NewValueType type)
        {
            if (string.IsNullOrWhiteSpace(rawData))
                return new WriteResult(false, "Data is empty — nothing was created.");

            if (!TryConvert(rawData, type, out object data, out string err))
                return new WriteResult(false, err);

            try
            {
                using var baseKey = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64);

                using var key = string.IsNullOrEmpty(keyPath)
                    ? baseKey
                    : baseKey.CreateSubKey(keyPath, writable: true);
                if (key == null)
                    return new WriteResult(false, "Could not open/create the key.");

                key.SetValue(valueName, data, ToKind(type));
                return new WriteResult(true, $"Created {valueName} in {HiveShort(hive)}\\{keyPath}");
            }
            catch (UnauthorizedAccessException)
            {
                return new WriteResult(false, "Access denied. Run the app as administrator to write here.");
            }
            catch (Exception ex)
            {
                return new WriteResult(false, "Write failed: " + ex.Message);
            }
        }

        private static bool TryConvert(string s, NewValueType type, out object data, out string err)
        {
            err = ""; data = s;
            try
            {
                switch (type)
                {
                    case NewValueType.String:
                    case NewValueType.ExpandString:
                        data = s;
                        return true;

                    case NewValueType.Dword:
                        data = (int)ParseUInt(s);
                        return true;

                    case NewValueType.Qword:
                        data = (long)ParseULong(s);
                        return true;

                    case NewValueType.Binary:
                        data = ParseHexBytes(s);
                        return true;

                    case NewValueType.MultiString:

                        data = s.Split(new[] { '|', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                                .Select(x => x.Trim()).ToArray();
                        return true;
                }
            }
            catch (Exception ex) { err = "Bad data for selected type: " + ex.Message; return false; }
            err = "Unsupported type.";
            return false;
        }

        private static uint ParseUInt(string s)
        {
            s = s.Trim();
            return s.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                ? Convert.ToUInt32(s.Substring(2), 16)
                : uint.Parse(s, CultureInfo.InvariantCulture);
        }

        private static ulong ParseULong(string s)
        {
            s = s.Trim();
            return s.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                ? Convert.ToUInt64(s.Substring(2), 16)
                : ulong.Parse(s, CultureInfo.InvariantCulture);
        }

        private static byte[] ParseHexBytes(string s)
        {
            var clean = s.Replace("-", " ").Replace(",", " ");
            var parts = clean.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length == 1 && parts[0].Length % 2 == 0 && parts[0].Length > 2)
            {
                var one = parts[0];
                var b = new byte[one.Length / 2];
                for (int i = 0; i < b.Length; i++)
                    b[i] = Convert.ToByte(one.Substring(i * 2, 2), 16);
                return b;
            }
            return parts.Select(p => Convert.ToByte(p, 16)).ToArray();
        }

        private static RegistryValueKind ToKind(NewValueType t) => t switch
        {
            NewValueType.String => RegistryValueKind.String,
            NewValueType.ExpandString => RegistryValueKind.ExpandString,
            NewValueType.Dword => RegistryValueKind.DWord,
            NewValueType.Qword => RegistryValueKind.QWord,
            NewValueType.Binary => RegistryValueKind.Binary,
            NewValueType.MultiString => RegistryValueKind.MultiString,
            _ => RegistryValueKind.String,
        };

        public static string HiveShort(RegistryHive h) => h switch
        {
            RegistryHive.LocalMachine => "HKLM",
            RegistryHive.CurrentUser => "HKCU",
            RegistryHive.ClassesRoot => "HKCR",
            RegistryHive.Users => "HKU",
            _ => h.ToString(),
        };
    }
}
