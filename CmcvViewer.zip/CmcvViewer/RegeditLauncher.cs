using System;
using System.Diagnostics;
using Microsoft.Win32;

namespace CmcvViewer
{

    public static class RegeditLauncher
    {
        private const string RegeditSettings =
            @"Software\Microsoft\Windows\CurrentVersion\Applets\Regedit";

        public static string Open(RegistryHive hive, string subPath)
        {
            string full = HiveRoot(hive);
            if (!string.IsNullOrEmpty(subPath))
                full += "\\" + subPath.Trim('\\');

            try
            {

                using (var key = Registry.CurrentUser.CreateSubKey(RegeditSettings, true))
                {
                    key?.SetValue("LastKey", "Computer\\" + full, RegistryValueKind.String);
                }

                Process.Start(new ProcessStartInfo
                {
                    FileName = "regedit.exe",
                    UseShellExecute = true,
                });

                return "Opened in regedit: " + full;
            }
            catch (Exception ex)
            {
                return "Could not open regedit: " + ex.Message;
            }
        }

        private static string HiveRoot(RegistryHive hive) => hive switch
        {
            RegistryHive.LocalMachine => "HKEY_LOCAL_MACHINE",
            RegistryHive.CurrentUser => "HKEY_CURRENT_USER",
            RegistryHive.ClassesRoot => "HKEY_CLASSES_ROOT",
            RegistryHive.Users => "HKEY_USERS",
            RegistryHive.CurrentConfig => "HKEY_CURRENT_CONFIG",
            _ => "HKEY_LOCAL_MACHINE",
        };
    }
}
