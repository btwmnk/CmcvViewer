using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Win32;

namespace CmcvViewer
{
    public sealed partial class MainWindow : Window
    {
        private string _section = "cmcv";
        private readonly ObservableCollection<TreeNode> _treeRoots = new();
        private readonly ObservableCollection<ValueRow> _values = new();

        private List<CmcvEntry> _cmcv = new();

        private TreeNode? _selectedNode;

        public MainWindow()
        {
            InitializeComponent();
            ExtendsContentIntoTitleBar = true;
            SetTitleBar(AppTitleBar);
            Title = "Control Registry Viewer";

            Tree.ItemsSource = _treeRoots;
            ValueList.ItemsSource = _values;
            Nav.SelectedItem = Nav.MenuItems[0];
        }

        private void OnSectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
        {
            if (args.SelectedItem is NavigationViewItem item && item.Tag is string tag)
            {
                _section = tag;
                bool isReg = tag == "reg";
                bool isCmcv = tag == "cmcv";

                PathBox.Visibility = isReg ? Visibility.Visible : Visibility.Collapsed;
                OpenButton.Visibility = (isReg || isCmcv) ? Visibility.Visible : Visibility.Collapsed;

                FilterBox.Visibility = isCmcv ? Visibility.Visible : Visibility.Collapsed;
                OnlyExistingCheck.Visibility = isCmcv ? Visibility.Visible : Visibility.Collapsed;
                _selectedNode = null;
                _treeRoots.Clear();
                _values.Clear();
                Notice.Visibility = Visibility.Collapsed;

                if (tag == "driveronly")
                {
                    ShowNotice(
                        "SSDT (KiServiceTable) and kernel notify-callbacks live only in kernel " +
                        "memory. Reading them needs a helper driver and (for the WinDbg driver) " +
                        "debug mode — the same requirement WinObjEx64 has.\n\n" +
                        "This tool stays driver-free, so these are intentionally not shown here. " +
                        "Use WinObjEx64 for them.");
                    StatusText.Text = "Driver-only section.";
                }
                else
                {
                    StatusText.Text = tag switch
                    {
                        "cmcv"     => "Press Load to parse CmControlVector and check the registry.",
                        "reg"      => "Pick a bookmark on the left or type a path, then Load.",
                        "drivers"  => "Press Load to list loaded kernel modules.",
                        "software" => "Press Load to list installed programs.",
                        "kusd"     => "Press Load to read KUSER_SHARED_DATA.",
                        "boot"     => "Press Load to read boot / Code Integrity info.",
                        _ => "",
                    };
                    if (tag == "reg") PopulateBookmarks();
                }
            }
        }

        private void ShowNotice(string text)
        {
            NoticeText.Text = text;
            Notice.Visibility = Visibility.Visible;
        }

        private async void OnScan(object sender, RoutedEventArgs e)
        {
            ScanButton.IsEnabled = false;
            try
            {
                switch (_section)
                {
                    case "cmcv": await LoadCmcv(); break;
                    case "reg": LoadRegistryRoots(); break;
                    case "drivers": await LoadDrivers(); break;
                    case "software": LoadSoftware(); break;
                    case "kusd": LoadKusd(); break;
                    case "boot": LoadBoot(); break;
                }
            }
            catch (Exception ex) { StatusText.Text = "Error: " + ex.Message; }
            finally { ScanButton.IsEnabled = true; }
        }

        private async Task LoadCmcv()
        {
            StatusText.Text = "Scanning ntoskrnl…";
            _treeRoots.Clear(); _values.Clear();

            var (entries, path, diag) = await Task.Run(() =>
            {
                var list = CmControlVectorReader.Read(out string p, out string d);
                RegistryChecker.Annotate(list);
                return (list, p, d);
            });

            _cmcv = entries;
            RebuildCmcvTree();

            int existing = _cmcv.Count(x => x.KeyExists);
            StatusText.Text = string.IsNullOrEmpty(diag)
                ? $"{_cmcv.Count} entries · {existing} present in registry · {System.IO.Path.GetFileName(path)}"
                : diag;
        }

        private void RebuildCmcvTree()
        {
            _treeRoots.Clear();
            _cmcvGroups.Clear();
            bool onlyExisting = OnlyExistingCheck.IsChecked == true;
            string q = (FilterBox.Text ?? "").Trim();

            IEnumerable<CmcvEntry> src = _cmcv;
            if (onlyExisting) src = src.Where(x => x.KeyExists);
            if (q.Length > 0)
                src = src.Where(x => x.KeyPath.Contains(q, StringComparison.OrdinalIgnoreCase)
                                  || x.ValueName.Contains(q, StringComparison.OrdinalIgnoreCase));

            foreach (var group in src.GroupBy(x => string.IsNullOrEmpty(x.KeyPath) ? "(Control)" : x.KeyPath)
                                     .OrderBy(g => g.Key, StringComparer.OrdinalIgnoreCase))
            {

                string relKeyPath = ControlPath(group.Key);
                var node = new TreeNode
                {
                    Name = group.Key,
                    HasValues = true,
                    ChildrenLoaded = true,

                    Hive = Microsoft.Win32.RegistryHive.LocalMachine,
                    FullPath = relKeyPath,
                };
                node.Exists = group.Any(x => x.KeyExists);
                _cmcvGroups[node] = group
                    .OrderBy(x => x.ValueName, StringComparer.OrdinalIgnoreCase)
                    .Select(x =>
                    {
                        bool missing = !x.ValueExists;
                        bool namedValue = !string.IsNullOrEmpty(x.ValueName);
                        return new ValueRow
                        {
                            Name = namedValue ? x.ValueName : "(key only)",
                            Type = x.ValueExists ? "value" : x.KeyExists ? "key" : "absent",
                            Data = x.Data ?? "",

                            CanCreate = missing && namedValue,
                            TargetHive = Microsoft.Win32.RegistryHive.LocalMachine,
                            TargetKeyPath = relKeyPath,
                            TargetValueName = x.ValueName,
                        };
                    }).ToList();
                _treeRoots.Add(node);
            }
            int shownEntries = _cmcvGroups.Values.Sum(v => v.Count);
            StatusText.Text =
                $"{_treeRoots.Count} keys · {shownEntries} of {_cmcv.Count} entries shown" +
                (OnlyExistingCheck.IsChecked == true ? " (filtered: only existing)" : "");
        }

        private readonly Dictionary<TreeNode, List<ValueRow>> _cmcvGroups = new();

        private void PopulateBookmarks()
        {
            _treeRoots.Clear();
            foreach (var b in Bookmarks.All)
            {
                var root = RegistryModel.BuildNode(b.Hive, b.Path, b.Label);
                _treeRoots.Add(root);
            }
            StatusText.Text = $"{_treeRoots.Count} bookmarks. Expand or type a custom path.";
        }

        private void LoadRegistryRoots() => PopulateBookmarks();

        private void OnPathKeyDown(object sender, Microsoft.UI.Xaml.Input.KeyRoutedEventArgs e)
        {
            if (e.Key == Windows.System.VirtualKey.Enter) { NavigateToTypedPath(); e.Handled = true; }
        }

        private void OnOpenPath(object sender, RoutedEventArgs e)
        {
            var node = (Tree.SelectedItem as TreeNode) ?? _selectedNode;

            if ((node == null || node.FullPath == null) && _section == "reg")
            {
                string text = (PathBox.Text ?? "").Trim();
                if (text.Length > 0 && RegistryModel.TryParsePath(text, out var h, out var p))
                {
                    StatusText.Text = RegeditLauncher.Open(h, p);
                    return;
                }
            }

            if (node == null || node.FullPath == null)
            {
                StatusText.Text = "Select a key in the tree first, then press Open.";
                return;
            }

            StatusText.Text = RegeditLauncher.Open(node.Hive, node.FullPath);
        }

        private void NavigateToTypedPath()
        {
            if (_section != "reg") return;
            string text = (PathBox.Text ?? "").Trim();
            if (text.Length == 0) { StatusText.Text = "Type a path, e.g. HKLM\\SYSTEM\\...\\Control"; return; }

            if (!RegistryModel.TryParsePath(text, out var hive, out var path))
            {
                StatusText.Text = "Unrecognized root. Use HKLM / HKCU / HKCR / HKU.";
                return;
            }

            var node = RegistryModel.BuildNode(hive, path, text);
            _treeRoots.Insert(0, node);
            Tree.SelectedItem = node;

            _values.Clear();
            foreach (var r in RegistryModel.ListValues(hive, path)) _values.Add(r);

            StatusText.Text = node.Exists
                ? $"{RegistryWriter.HiveShort(hive)}\\{path}  ·  {_values.Count} values"
                : "Path not found (shown dimmed).";
        }

        private async Task LoadDrivers()
        {
            StatusText.Text = "Querying loaded modules…";
            _treeRoots.Clear(); _values.Clear();
            var (drivers, diag) = await Task.Run(() =>
            {
                var d = DriverListReader.Read(out string dg);
                return (d, dg);
            });

            foreach (var d in drivers.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
                _values.Add(new ValueRow { Name = d.Name, Type = d.ImageBase, Data = d.Path });

            StatusText.Text = string.IsNullOrEmpty(diag)
                ? $"{drivers.Count} loaded modules."
                : diag;
        }

        private void LoadBoot()
        {
            _treeRoots.Clear(); _values.Clear();
            foreach (var r in BootInfoReader.Read()) _values.Add(r);
            StatusText.Text = $"{_values.Count} properties.";
        }

        private void LoadSoftware()
        {
            _treeRoots.Clear(); _values.Clear();
            foreach (var r in InstalledSoftwareReader.Read()) _values.Add(r);
            StatusText.Text = $"{_values.Count} installed programs.";
        }

        private void LoadKusd()
        {
            _treeRoots.Clear(); _values.Clear();
            foreach (var r in KUserSharedDataReader.Read()) _values.Add(r);
            StatusText.Text = $"KUSER_SHARED_DATA · {_values.Count} fields.";
        }

        private void OnTreeExpanding(TreeView sender, TreeViewExpandingEventArgs args)
        {
            if (args.Item is not TreeNode node) return;
            if (_section == "reg")
            {
                foreach (var child in node.Children)
                    RegistryModel.LoadChildren(child);
            }
        }

        private void OnTreeInvoked(TreeView sender, TreeViewItemInvokedEventArgs args)
        {
            if (args.InvokedItem is not TreeNode node) return;
            _selectedNode = node;
            _values.Clear();

            if (_section == "cmcv")
            {
                if (_cmcvGroups.TryGetValue(node, out var rows))
                    foreach (var r in rows) _values.Add(r);
                StatusText.Text = node.Name;
            }
            else if (_section == "reg" && node.FullPath != null)
            {
                RegistryModel.LoadChildren(node);
                foreach (var r in RegistryModel.ListValues(node.Hive, node.FullPath)) _values.Add(r);
                StatusText.Text = $"{HiveShort(node.Hive)}\\{node.FullPath}  ·  {_values.Count} values";
            }
        }

        private static string HiveShort(RegistryHive h) => h switch
        {
            RegistryHive.LocalMachine => "HKLM",
            RegistryHive.CurrentUser => "HKCU",
            RegistryHive.ClassesRoot => "HKCR",
            RegistryHive.Users => "HKU",
            _ => h.ToString(),
        };

        private void OnFilter(object sender, TextChangedEventArgs e) { if (_section == "cmcv") RebuildCmcvTree(); }
        private void OnFilterToggle(object sender, RoutedEventArgs e) { if (_section == "cmcv") RebuildCmcvTree(); }

        private const string ControlBase = @"SYSTEM\CurrentControlSet\Control";
        private static string ControlPath(string groupKey)
        {
            if (string.IsNullOrEmpty(groupKey) || groupKey == "(Control)") return ControlBase;
            string rel = groupKey.Replace('/', '\\').Trim('\\');
            int idx = rel.IndexOf(@"Control\", StringComparison.OrdinalIgnoreCase);
            if (idx >= 0) rel = rel.Substring(idx + "Control\\".Length);
            return rel.Length == 0 ? ControlBase : ControlBase + "\\" + rel;
        }

        private async void OnCreateValue(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not ValueRow row) return;

            var res = await CreateValueDialog.ShowAsync(
                RootGrid.XamlRoot,
                $"HKLM\\{row.TargetKeyPath}",
                row.TargetValueName);

            if (res == null || !res.Confirmed)
            {
                StatusText.Text = "Cancelled — nothing created.";
                return;
            }

            var result = RegistryWriter.CreateValue(
                row.TargetHive, row.TargetKeyPath, row.TargetValueName, res.Data, res.Type);

            StatusText.Text = result.Message;

            if (result.Ok)
            {

                await Task.Run(() => RegistryChecker.Annotate(_cmcv));
                RebuildCmcvTree();
            }
        }
    }
}
