using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

namespace CmcvViewer
{

    public sealed class CmcvEntry
    {
        public string KeyPath = "";
        public string ValueName = "";
        public uint Type;
        public uint Flags;

        public bool KeyExists;
        public bool ValueExists;
        public string? Data;

        public string StatusText =>
            ValueExists ? "value" : KeyExists ? "key" : "—";

        public Microsoft.UI.Xaml.Media.SolidColorBrush StatusBrush =>
            new(ValueExists
                ? Windows.UI.Color.FromArgb(255, 106, 212, 106)
                : KeyExists
                    ? Windows.UI.Color.FromArgb(255, 220, 190, 90)
                    : Windows.UI.Color.FromArgb(255, 120, 120, 120));
    }

    public static class CmControlVectorReader
    {

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr LoadLibraryEx(string lpFileName, IntPtr hFile, uint dwFlags);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool FreeLibrary(IntPtr hModule);

        private const uint DONT_RESOLVE_DLL_REFERENCES = 0x00000001;

        public static List<CmcvEntry> Read(out string ntoskrnlPath, out string diagnostics)
        {
            var result = new List<CmcvEntry>();
            diagnostics = "";
            ntoskrnlPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.System),
                "ntoskrnl.exe");

            if (!File.Exists(ntoskrnlPath))
                throw new FileNotFoundException("ntoskrnl.exe not found", ntoskrnlPath);

            IntPtr hMod = LoadLibraryEx(ntoskrnlPath, IntPtr.Zero, DONT_RESOLVE_DLL_REFERENCES);
            if (hMod == IntPtr.Zero)
                throw new InvalidOperationException(
                    $"LoadLibraryEx failed, error {Marshal.GetLastWin32Error()}");

            try
            {

                ulong moduleBase = (ulong)(hMod.ToInt64() & ~3L);

                PeImage pe = PeImage.Parse(moduleBase);

                byte[] needle = System.Text.Encoding.Unicode.GetBytes("ProtectionMode\0");
                ulong strAddr = pe.FindBytes(needle);
                if (strAddr == 0)
                {
                    diagnostics = "Could not locate the ProtectionMode marker string in ntoskrnl.";
                    return result;
                }

                var refs = pe.FindAllPointersTo(strAddr);
                if (refs.Count == 0)
                {
                    diagnostics = "Found ProtectionMode string but no reference to it (unexpected ntoskrnl layout).";
                    return result;
                }

                uint[] candidateSizes = { 48u, 40u, 56u, 64u };

                List<CmcvEntry> best = new();
                List<CmcvEntry> bestAny = new();
                string bestDiag = "";

                foreach (var valueNameSlot in refs)
                {

                    ulong entry = valueNameSlot - 8;

                    foreach (var size in candidateSizes)
                    {
                        ulong start = WalkBackToStart(pe, entry, size);
                        var got = WalkForward(pe, start, size, out string d);

                        if (got.Count > bestAny.Count) bestAny = got;

                        bool consistent = got.Exists(x =>
                            x.ValueName.Equals("ProtectionMode", StringComparison.OrdinalIgnoreCase));
                        if (consistent && got.Count > best.Count) { best = got; bestDiag = d; }
                    }
                }

                result = best.Count > 0 ? best : bestAny;
                diagnostics = best.Count > 0 ? bestDiag
                    : "Parsed the array with a fallback heuristic; count may be approximate.";
            }
            finally
            {
                FreeLibrary(hMod);
            }

            return result;
        }

        private static bool LooksLikeEntry(PeImage pe, ulong addr)
        {
            ulong keyPtr = pe.ReadPtr(addr);
            if (keyPtr == 0 || !pe.IsReadableStringPointer(keyPtr)) return false;
            ulong valPtr = pe.ReadPtr(addr + 8);
            if (valPtr != 0 && !pe.Contains(valPtr)) return false;
            return true;
        }

        private static ulong WalkBackToStart(PeImage pe, ulong knownEntry, uint entrySize)
        {
            ulong cur = knownEntry;
            while (cur >= entrySize && LooksLikeEntry(pe, cur - entrySize))
                cur -= entrySize;
            return cur;
        }

        private static List<CmcvEntry> WalkForward(PeImage pe, ulong start, uint entrySize, out string diag)
        {
            diag = "";
            var list = new List<CmcvEntry>();
            ulong cur = start;
            int guard = 0;

            while (guard++ < 65536)
            {
                ulong keyPtr = pe.ReadPtr(cur);

                if (keyPtr == 0) break;
                if (!pe.Contains(keyPtr)) break;

                ulong valPtr = pe.ReadPtr(cur + 8);

                var e = new CmcvEntry
                {
                    KeyPath = pe.ReadWideString(keyPtr),
                    ValueName = (valPtr != 0 && pe.Contains(valPtr))
                        ? pe.ReadWideString(valPtr) : "",
                };

                try
                {
                    ulong typePtr = pe.ReadPtr(cur + 32);
                    if (typePtr != 0 && pe.Contains(typePtr))
                        e.Type = pe.ReadU32(typePtr);
                    if (pe.IsWin10Rs4OrLater)
                        e.Flags = pe.ReadU32(cur + 40);
                }
                catch {  }

                list.Add(e);
                cur += entrySize;
            }

            if (list.Count == 0)
                diag = "Walked the array but found no valid entries.";
            return list;
        }
    }
}
