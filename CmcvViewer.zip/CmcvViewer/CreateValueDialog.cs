using System;
using System.Threading.Tasks;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace CmcvViewer
{

    public static class CreateValueDialog
    {
        public sealed class Result
        {
            public bool Confirmed;
            public string Data = "";
            public NewValueType Type;
        }

        public static async Task<Result?> ShowAsync(
            XamlRoot xamlRoot, string keyPathDisplay, string valueName)
        {
            var typeBox = new ComboBox
            {
                Header = "Type",
                SelectedIndex = 0,
                HorizontalAlignment = HorizontalAlignment.Stretch,
            };
            typeBox.Items.Add("REG_SZ (String)");
            typeBox.Items.Add("REG_EXPAND_SZ");
            typeBox.Items.Add("REG_DWORD");
            typeBox.Items.Add("REG_QWORD");
            typeBox.Items.Add("REG_BINARY (hex)");
            typeBox.Items.Add("REG_MULTI_SZ (| separated)");

            var dataBox = new TextBox
            {
                Header = "Data (required)",
                PlaceholderText = "value data — cannot be empty",
                AcceptsReturn = false,
                Margin = new Thickness(0, 8, 0, 0),
            };

            var info = new TextBlock
            {
                Text = $"Key:  {keyPathDisplay}\nValue:  {valueName}",
                FontSize = 12,
                Opacity = 0.8,
                Margin = new Thickness(0, 0, 0, 6),
                TextWrapping = TextWrapping.Wrap,
            };

            var panel = new StackPanel { Spacing = 2, MinWidth = 360 };
            panel.Children.Add(info);
            panel.Children.Add(typeBox);
            panel.Children.Add(dataBox);

            var dialog = new ContentDialog
            {
                Title = "Create registry value",
                Content = panel,
                PrimaryButtonText = "Create",
                CloseButtonText = "Cancel",
                DefaultButton = ContentDialogButton.Primary,
                XamlRoot = xamlRoot,
                IsPrimaryButtonEnabled = false,
            };

            dataBox.TextChanged += (_, _) =>
                dialog.IsPrimaryButtonEnabled = !string.IsNullOrWhiteSpace(dataBox.Text);

            var outcome = await dialog.ShowAsync();
            if (outcome != ContentDialogResult.Primary)
                return new Result { Confirmed = false };

            if (string.IsNullOrWhiteSpace(dataBox.Text))
                return new Result { Confirmed = false };

            return new Result
            {
                Confirmed = true,
                Data = dataBox.Text,
                Type = (NewValueType)typeBox.SelectedIndex,
            };
        }
    }
}
