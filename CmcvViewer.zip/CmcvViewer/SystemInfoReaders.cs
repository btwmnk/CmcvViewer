using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace CmcvViewer
{
    public sealed class DriverRow
    {
        public string Name = "";
        public string ImageBase = "";
        public string Size = "";
        public string Path = "";
    }

    public static class DriverListReader
    {
        private const int SystemModuleInformation = 11;

        [DllImport("ntdll.dll")]
        private static extern int NtQuerySystemInformation(
            int SystemInformationClass, IntPtr SystemInformation,
            int SystemInformationLength, out int ReturnLength);

        [StructLayout(LayoutKind.Sequential)]
        private struct RTL_PROCESS_MODULE_INFORMATION
        {
            public IntPtr Section;
            public IntPtr MappedBase;
            public IntPtr ImageBase;
            public uint ImageSize;
            public uint Flags;
            public ushort LoadOrderIndex;
            public ushort InitOrderIndex;
            public ushort LoadCount;
            public ushort OffsetToFileName;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public byte[] FullPathName;
        }

        public static List<DriverRow> Read(out string diag)
        {
            diag = "";
            var list = new List<DriverRow>();
            int len = 0;
            NtQuerySystemInformation(SystemModuleInformation, IntPtr.Zero, 0, out len);
            if (len <= 0) { diag = "NtQuerySystemInformation returned no size."; return list; }

            len *= 2;
            IntPtr buf = Marshal.AllocHGlobal(len);
            try
            {
                int status = NtQuerySystemInformation(SystemModuleInformation, buf, len, out _);
                if (status != 0) { diag = $"NtQuerySystemInformation status 0x{status:X8}"; return list; }

                int count = Marshal.ReadInt32(buf);
                IntPtr p = buf + IntPtr.Size;
                int structSize = Marshal.SizeOf<RTL_PROCESS_MODULE_INFORMATION>();

                for (int i = 0; i < count; i++)
                {
                    var m = Marshal.PtrToStructure<RTL_PROCESS_MODULE_INFORMATION>(p + i * structSize);
                    string full = BytesToString(m.FullPathName);
                    string name = m.OffsetToFileName < full.Length
                        ? full.Substring(m.OffsetToFileName) : full;

                    list.Add(new DriverRow
                    {
                        Name = name,
                        ImageBase = "0x" + m.ImageBase.ToInt64().ToString("X"),
                        Size = "0x" + m.ImageSize.ToString("X"),
                        Path = full.Replace(@"\SystemRoot\", @"%SystemRoot%\"),
                    });
                }
            }
            finally { Marshal.FreeHGlobal(buf); }

            return list;
        }

        private static string BytesToString(byte[] b)
        {
            int n = Array.IndexOf(b, (byte)0);
            if (n < 0) n = b.Length;
            return System.Text.Encoding.ASCII.GetString(b, 0, n);
        }
    }

    public static class BootInfoReader
    {
        public static List<ValueRow> Read()
        {
            var rows = new List<ValueRow>();
            var os = Environment.OSVersion.Version;
            rows.Add(Row("Windows version", "Info", $"{os.Major}.{os.Minor} build {os.Build}"));
            rows.Add(Row("64-bit OS", "Info", Environment.Is64BitOperatingSystem.ToString()));

            AddReg(rows, RegistryHive.LocalMachine,
                @"SOFTWARE\Microsoft\Windows NT\CurrentVersion",
                new[] { "ProductName", "DisplayVersion", "CurrentBuild", "UBR", "BuildLabEx" });

            AddReg(rows, RegistryHive.LocalMachine,
                @"SYSTEM\CurrentControlSet\Control\SecureBoot\State",
                new[] { "UEFISecureBootEnabled" });

            AddReg(rows, RegistryHive.LocalMachine,
                @"SYSTEM\CurrentControlSet\Control\DeviceGuard",
                new[] { "EnableVirtualizationBasedSecurity", "RequirePlatformSecurityFeatures" });
            AddReg(rows, RegistryHive.LocalMachine,
                @"SYSTEM\CurrentControlSet\Control\CI\Policy",
                new[] { "VerifiedAndReputablePolicyState" });

            AddReg(rows, RegistryHive.LocalMachine,
                @"SYSTEM\CurrentControlSet\Control\CrashControl",
                new[] { "CrashDumpEnabled" });

            return rows;
        }

        private static void AddReg(List<ValueRow> rows, RegistryHive hive, string path, string[] names)
        {
            try
            {
                using var baseKey = RegistryModel.OpenBase(hive);
                using var key = baseKey.OpenSubKey(path, false);
                if (key == null) return;
                foreach (var n in names)
                {
                    var v = key.GetValue(n, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                    if (v != null) rows.Add(Row(n, key.GetValueKind(n).ToString(), v.ToString() ?? ""));
                }
            }
            catch {  }
        }

        private static ValueRow Row(string n, string t, string d) => new() { Name = n, Type = t, Data = d };
    }

    public static class InstalledSoftwareReader
    {
        public static List<ValueRow> Read()
        {
            var rows = new List<ValueRow>();
            Scan(RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64),
                 @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", rows);
            Scan(RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32),
                 @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", rows);
            Scan(RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64),
                 @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", rows);

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var result = new List<ValueRow>();
            foreach (var r in rows)
            {
                if (r.Name.Length == 0 || !seen.Add(r.Name)) continue;
                result.Add(r);
            }
            result.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
            return result;
        }

        private static void Scan(RegistryKey baseKey, string path, List<ValueRow> rows)
        {
            try
            {
                using (baseKey)
                using (var root = baseKey.OpenSubKey(path, false))
                {
                    if (root == null) return;
                    foreach (var sub in root.GetSubKeyNames())
                    {
                        try
                        {
                            using var k = root.OpenSubKey(sub, false);
                            if (k == null) continue;
                            string name = k.GetValue("DisplayName") as string ?? "";
                            if (string.IsNullOrWhiteSpace(name)) continue;
                            string ver = k.GetValue("DisplayVersion") as string ?? "";
                            string pub = k.GetValue("Publisher") as string ?? "";
                            rows.Add(new ValueRow { Name = name, Type = ver, Data = pub });
                        }
                        catch { }
                    }
                }
            }
            catch { }
        }
    }
}
